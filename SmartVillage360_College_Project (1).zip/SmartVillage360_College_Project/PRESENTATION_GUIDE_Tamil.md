# SmartVillage 360 — 2-minute Presentation

**Good morning respected staff and my dear friends.**

My project title is **SmartVillage 360 — Digital Village**. The aim of this project is to bring common village services into one simple website. Citizens can create an account, raise public complaints, view their complaint status, and read village announcements. Farmers can open useful agriculture resource links. The administrator can review complaints, update their status, publish notices, and export reports.

For the demonstration, I will first create or log in as a citizen and submit a sample complaint. Then I will log out and sign in using the demo administrator account. In the Admin Panel, I will update the complaint status and publish an announcement. Finally, I will show the CSV report export.

The current version is a frontend prototype that stores demo data in the browser, so it is suitable for demonstrating the workflow. A real village-wide deployment would require a secure backend and shared online database.

**Thank you.**

## Project Flow
Home → Create Account/Login → Citizen Dashboard → Submit Complaint → Admin Login → Update Status / Publish Notice → Export Report
