# SmartVillage 360 — Digital Village

கல்லூரி project demonstration-க்கான responsive, single-file website.

## இதில் வேலை செய்யும் அம்சங்கள்
- Citizen / Farmer account create மற்றும் login
- Dashboard: complaints summary, quick links
- Complaint பதிவு மற்றும் status tracking
- Admin login மூலம் complaint status-ஐ Pending / In Progress / Resolved என மாற்றுதல்
- Admin மூலம் announcements publish செய்தல்
- User profile update
- Agriculture resource links
- Complaint CSV export மற்றும் admin JSON backup (passwords சேர்க்கப்படாது)
- Mobile மற்றும் desktop layout

## Demo-க்கு Login விவரங்கள்
**Admin email:** `admin@smartvillage.local`  
**Admin password:** `Village@360`

Citizen account உருவாக்க, Home page → Get Started → Create Account பயன்படுத்தவும்.

## உங்கள் GitHub Pages-ல் online செய்வது
1. GitHub-ல் ஒரு புதிய **Public repository** உருவாக்கவும் (உதாரணம்: `SmartVillage360`).
2. இந்த folder-இல் உள்ள `index.html` மட்டும் repository-யின் root-ல் upload செய்யவும்.
3. **Commit changes** செய்யவும்.
4. Repository → **Settings → Pages** திறக்கவும்.
5. **Deploy from a branch** தேர்வு செய்யவும்; Branch `main`, folder `/(root)`; Save அழுத்தவும்.
6. Publish ஆனதும் URL இதுபோல இருக்கும்: `https://YOUR-USERNAME.github.io/REPOSITORY-NAME/`.

## கல்லூரியில் demo காட்டும் வரிசை
1. Website open செய்து Create Account மூலம் citizen account உருவாக்கவும்.
2. Dashboard → Raise Complaint மூலம் ஒரு sample complaint பதிவு செய்யவும்.
3. My Complaints-ல் complaint இருப்பதை காட்டவும்; CSV export-ஐயும் காட்டலாம்.
4. Logout செய்து Admin credentials மூலம் login செய்யவும்.
5. Admin Panel-ல் complaint status-ஐ Resolved ஆக மாற்றவும்; புதிய announcement publish செய்யவும்.
6. Citizen account-ல் மீண்டும் login செய்து மாற்றங்களைச் சரிபார்க்கவும். அதே browser/device-ல் data சேமிக்கப்பட்டிருந்தால் இவை demo-வில் தெரியும்.

## முக்கியமான தொழில்நுட்பக் குறிப்பு
இது கல்லூரி presentation-க்கு ஏற்ற **frontend prototype**. Accounts, complaints, notices ஆகியவை browser `localStorage`-ல் சேமிக்கப்படுகின்றன. அதனால் data அந்த browser/device-க்கு மட்டுமே; வேறு நபரின் mobile-ல் தானாகப் பகிரப்படாது. இது real production authentication அல்ல; passwords browser storage-ல் plaintext-ஆக உள்ளன. உண்மையான public service-க்கு Firebase/Supabase அல்லது secure backend + database, server-side authorization, HTTPS மற்றும் privacy/security review அவசியம். இந்த demo-வில் உண்மையான குடிமக்களின் தனிப்பட்ட data பயன்படுத்த வேண்டாம்.
